public class Catioro {
    private String nome;
    private String raca;

    public Catioro(String nome, String raca) {
        this.nome = nome;
        this.raca = raca;
    }
    public void info() {
        System.out.println("O cachorro se chama: " + nome + ". Ele é da raça: " + raca);
    }

    public void latir() {
        System.out.println(nome + " está latindo!");
    }

    public void comer() {
        System.out.println(nome + " está comendo.");
    }

    public static void main(String[] args) {
        Catioro catioro = new Catioro("Rex", "Labrador");
        catioro.info();
        catioro.latir();
        catioro.comer();
    }
}